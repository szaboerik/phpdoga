<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lista</title>
</head>
<body>
  <div style="width: 90%; margin: auto;">
  <table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Neve</th>
        <th scope="col">Megjelenés</th>
        <th scope="col">Típusa</th>
        <th scope="col">Ára</th>
        <th scope="col">Játékosok száma</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($tarsasok as $tarsas)
        <tr>
          <th scope="row">{{ $tarsas->id}}</th>
          <td>{{ $tarsas->nev }}</td>
          <td>{{ $tarsas->megjelenes }}</td>
          <td>{{ $tarsas->tipus }}</td>
          <td>{{ $tarsas->ar }}</td>
          <td>{{ $tarsas->jatekos }}</td>
          <td style="display: flex;">
            <a href="/tarsas/edit/{{ $tarsas->id }}"><button class="btn btn-sm btn-info">Szerkesztés</button></a>
            <a><form action="/api/tarsas/{{ $tarsas->id }}" method="POST">@csrf @method('delete')<button type="submit" class="btn btn-sm btn-danger">Törlés</button></form></a>
          </td>
        </tr>
      @endforeach
    </tbody>
    <div><a href="/tarsas/new"><button class="btn btn-sm btn-success">Új projekt létrehozása</button></a></div>
  </table>
</div>
</body>
</html>