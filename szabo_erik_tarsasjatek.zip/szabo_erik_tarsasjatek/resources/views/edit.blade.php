<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Módosít társas</title>
</head>
<body>
  <div>
    <form action="/api/tarsas/{{$tarsas->id }}" method="POST">
        @csrf
        @method('put')
      <div>
        <label for="id">ID</label>
        <div>
          <input type="number" id="id" name="id" class="form-control" value="{{$tarsas->id}}">
        </div>
      </div>
      <div>
        <label for="nev" >Neve</label>
        <div>
          <input type="text" id="nev" name="nev" value="{{ $tarsas->nev }}">
        </div>
      </div>
      <div>
        <label for="megjelenes" >Megjelenése</label>
        <div>
          <input type="date" id="megjelenes" name="megjelenes" value="{{$tarsas->megjelenes}}">
        </div>
      </div>
      <div>
        <label for="tipus" >Típusa</label>
        <div>
          <input type="text" id="tipus" name="tipus" value="{{$tarsas->tipus}}">
        </div>
      </div>
      <div>
        <label for="ar" >Ára</label>
        <div>
          <input type="number" id="ar" name="ar" value="{{$tarsas->ar}}">
        </div>
      </div>
      <div>
        <label for="jatekos">Játékos</label>
        <div>
          <input type="number" id="jatekos" name="jatekos" value="{{$tarsas->jatekos}}">
        </div>
      </div>
      <div>
      <button type="submit" class="btn btn-success">Mentés</button>
</div>
    </form>
  </div>
</body>
</html>