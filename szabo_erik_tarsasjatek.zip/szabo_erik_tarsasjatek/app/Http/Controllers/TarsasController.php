<?php

namespace App\Http\Controllers;

use App\Models\Tarsas;
use Illuminate\Http\Request;

class TarsasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Tarsas::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tarsas = new Tarsas();
        $tarsas->nev = $request->nev;
        $tarsas->megjelenes = $request->megjelenes;
        $tarsas->tipus = $request->tipus;
        $tarsas->ar = $request->ar;
        $tarsas->jatekos = $request->jatekos;
        $tarsas->save();

        return redirect('/api/tarsasok');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tarsas  $tarsas
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Tarsas::find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tarsas  $tarsas
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tarsas = Tarsas::find($id);
        return view('edit', ['tarsas' => $tarsas]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tarsas  $tarsas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tarsas = Tarsas::find($id);
        $tarsas->nev = $request->nev;
        $tarsas->megjelenes = $request->megjelenes;
        $tarsas->tipus = $request->tipus;
        $tarsas->ar = $request->ar;
        $tarsas->jatekos = $request->jatekos;
        $tarsas->save();

        return redirect('/api/tarsasok');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tarsas  $tarsas
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Tarsas::find($id)->delete();
        return redirect('/api/tarsasok');
    }
    public function list()
    {
        $tarsasok = Tarsas::all();
        return view('list', ['tarsasok' => $tarsasok]);
    }
}
