<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Módosít társas</title>
</head>
<body>
  <div>
    <form action="/api/tarsas/<?php echo e($tarsas->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
      <div>
        <label for="id">ID</label>
        <div>
          <input type="number" id="id" name="id" class="form-control" value="<?php echo e($tarsas->id); ?>">
        </div>
      </div>
      <div>
        <label for="nev" >Neve</label>
        <div>
          <input type="text" id="nev" name="nev" value="<?php echo e($tarsas->nev); ?>">
        </div>
      </div>
      <div>
        <label for="megjelenes" >Megjelenése</label>
        <div>
          <input type="number" id="megjelenes" name="megjelenes" value="<?php echo e($tarsas->megjelenes); ?>">
        </div>
      </div>
      <div>
        <label for="tipus" >Típusa</label>
        <div>
          <input type="text" id="tipus" name="tipus" value="<?php echo e($tarsas->tipus); ?>">
        </div>
      </div>
      <div>
        <label for="ar" >Ára</label>
        <div>
          <input type="number" id="ar" name="ar" value="<?php echo e($tarsas->ar); ?>">
        </div>
      </div>
      <div>
        <label for="jatekos">Játékos</label>
        <div>
          <input type="number" id="jatekos" name="jatekos" value="<?php echo e($tarsas->jatekos); ?>">
        </div>
      </div>
      <div>
      <button type="submit" class="btn btn-success">Mentés</button>
</div>
    </form>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\szabo_erik_tarsasjatek\resources\views/edit.blade.php ENDPATH**/ ?>