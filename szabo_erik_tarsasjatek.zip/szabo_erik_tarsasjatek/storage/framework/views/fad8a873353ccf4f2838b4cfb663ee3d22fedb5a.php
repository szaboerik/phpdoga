<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Új társas</title>
</head>
<body>
  <div>
    <form action="/api/tarsas" name="_token" method="POST">
        <?php echo csrf_field(); ?>
      <div>
        <label for="id">ID</label>
        <div>
          <input type="number" id="id" name="id" placeholder="ID-je">
        </div>
      </div>
      <div>
        <label for="nev" >Neve</label>
        <div>
          <input type="text" id="nev" name="nev" placeholder="Társas neve">
        </div>
      </div>
      <div>
        <label for="megjelenes" >Megjelenése</label>
        <div>
          <input type="date" id="megjelenes" name="megjelenes" placeholder="Megjelenése">
        </div>
      </div>
      <div>
        <label for="tipus" >Típusa</label>
        <div>
          <input type="text" id="tipus" name="tipus" placeholder="Típusa">
        </div>
      </div>
      <div>
        <label for="ar" >Ára</label>
        <div>
          <input type="number" id="ar" name="ar" placeholder="Ára">
        </div>
      </div>
      <div>
        <label for="jatekos">Játékos</label>
        <div>
          <input type="number" id="jatekos" name="jatekos" placeholder="Játékosok száma">
        </div>
      </div>
      <button type="submit" class="btn btn-success">Mentés</button>
    </form>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\szabo_erik_tarsasjatek\resources\views/new.blade.php ENDPATH**/ ?>