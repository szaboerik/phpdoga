<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lista</title>
</head>
<body>
  <div style="width: 90%; margin: auto;">
  <table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Neve</th>
        <th scope="col">Megjelenés</th>
        <th scope="col">Típusa</th>
        <th scope="col">Ára</th>
        <th scope="col">Játékosok száma</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $tarsasok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarsas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($tarsas->id); ?></th>
          <td><?php echo e($tarsas->nev); ?></td>
          <td><?php echo e($tarsas->megjelenes); ?></td>
          <td><?php echo e($tarsas->tipus); ?></td>
          <td><?php echo e($tarsas->ar); ?></td>
          <td><?php echo e($tarsas->jatekos); ?></td>
          <td style="display: flex;">
            <a href="/tarsas/edit/<?php echo e($tarsas->id); ?>"><button class="btn btn-sm btn-info">Szerkesztés</button></a>
            <a><form action="/api/tarsas/<?php echo e($tarsas->id); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button type="submit" class="btn btn-sm btn-danger">Törlés</button></form></a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <div><a href="/tarsas/new"><button class="btn btn-sm btn-success">Új projekt létrehozása</button></a></div>
  </table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\szabo_erik_tarsasjatek\resources\views/list.blade.php ENDPATH**/ ?>