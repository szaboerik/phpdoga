<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\TarsasController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Összes társasjáték
//Route::get('/api/tarsasok', [TarsasController::class, 'index']);
//Új társasjáték létrehozásA
//Route::post('api/ujtarsas', [TarsasController::class, 'store']);
//Módosítás
//Route::get('/api/modosit/{id}', [TarsasController::class, 'edit']);
//Törlés
//Route::get('/api/tarsas/{id}', [TarsasController::class, 'destroy']);
//Update
//Route::put('/api/tarsas/{id}', [TarsasController::class, 'update']);


Route::get('/api/tarsasok', [TarsasController::class, 'index']);
Route::get('/api/tarsas/{id}', [TarsasController::class, 'show']);
Route::post('/api/tarsas', [TarsasController::class, 'store']);
Route::put('/api/tarsas/{id}', [TarsasController::class, 'update']);
Route::delete('/api/tarsas/{id}', [TarsasController::class, 'destroy']);

Route::get('/tarsas/new', [TarsasController::class, 'create']);
Route::get('/tarsas/edit/{id}', [TarsasController::class, 'edit']);
Route::get('/tarsas/list', [TarsasController::class, 'list']);
